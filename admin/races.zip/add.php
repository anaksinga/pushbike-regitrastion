<!-- File: admin/races/add.php -->
<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
$pageTitle = 'Add Race';
requireLogin();
requireSuperAdmin();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $description = sanitize($_POST['description']);
    $location = sanitize($_POST['location']);
    $eventDate = sanitize($_POST['event_date']);
    $whatsappGroupLink = sanitize($_POST['whatsapp_group_link']);
    
    if (empty($name) || empty($location) || empty($eventDate)) {
        $_SESSION['error'] = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO races (name, description, location, event_date, whatsapp_group_link) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $description, $location, $eventDate, $whatsappGroupLink]);
            
            $_SESSION['success'] = "Race added successfully.";
            header("Location: index.php");
            exit;
        } catch(PDOException $e) {
            $_SESSION['error'] = "Error adding race: " . $e->getMessage();
        }
    }
}

include '../../includes/header.php';
?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Add New Race</h1>
        <a href="index.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-2"></i>Back to Races
        </a>
    </div>
    
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['error']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); endif; ?>
    
    <div class="card">
        <div class="card-body">
            <form method="post" action="" class="needs-validation" novalidate>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Race Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" required>
                        <div class="invalid-feedback">
                            Please provide a race name.
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="location" class="form-label">Location <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="location" name="location" required>
                        <div class="invalid-feedback">
                            Please provide a location.
                        </div>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="event_date" class="form-label">Event Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="event_date" name="event_date" required>
                        <div class="invalid-feedback">
                            Please provide an event date.
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="whatsapp_group_link" class="form-label">WhatsApp Group Link</label>
                        <input type="text" class="form-control" id="whatsapp_group_link" name="whatsapp_group_link" placeholder="https://chat.whatsapp.com/...">
                        <div class="form-text">This link will be shown to participants after successful registration.</div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                </div>
                
                <div class="d-flex justify-content-end">
                    <a href="index.php" class="btn btn-outline-secondary me-2">Cancel</a>
                    <button type="submit" class="btn btn-primary">Add Race</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>