<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
$pageTitle = 'Manage Races';
requireLogin();
requireSuperAdmin();

// Get all races
$races = getAllRaces();

include '../../includes/header.php';
?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Manage Races</h1>
        <a href="add.php" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>Add New Race
        </a>
    </div>
    
    <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['success']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $_SESSION['error']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); endif; ?>
    
    <div class="card">
        <div class="card-body">
            <?php if (count($races) > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Location</th>
                            <th>Date</th>
                            <th>Categories</th>
                            <th>Registrations</th>
                            <th>Photos</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($races as $race): ?>
                        <?php
                        // Get categories count for this race
                        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM categories WHERE race_id = ?");
                        $stmt->execute([$race['id']]);
                        $categoriesCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                        
                        // Get registrations count for this race
                        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM registrations WHERE race_id = ?");
                        $stmt->execute([$race['id']]);
                        $registrationsCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                        
                        // Get photos count for this race
                        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM event_photos WHERE race_id = ?");
                        $stmt->execute([$race['id']]);
                        $photosCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                        ?>
                        <tr>
                            <td><?php echo $race['id']; ?></td>
                            <td><?php echo $race['name']; ?></td>
                            <td><?php echo $race['description'] ?: 'No description'; ?></td>
                            <td><?php echo $race['location']; ?></td>
                            <td><?php echo formatDate($race['event_date']); ?></td>
                            <td>
                                <span class="badge bg-primary"><?php echo $categoriesCount; ?></span>
                            </td>
                            <td>
                                <span class="badge bg-success"><?php echo $registrationsCount; ?></span>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo $photosCount; ?></span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="view.php?id=<?php echo $race['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="edit.php?id=<?php echo $race['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="categories/index.php?race_id=<?php echo $race['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-tags"></i>
                                    </a>
                                    <a href="/admin/event_photos/index.php?race_id=<?php echo $race['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-images"></i>
                                    </a>
                                    <a href="delete.php?id=<?php echo $race['id']; ?>" class="btn btn-sm btn-outline-danger btn-delete">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-muted">No races found. <a href="add.php">Add a new race</a> to get started.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>